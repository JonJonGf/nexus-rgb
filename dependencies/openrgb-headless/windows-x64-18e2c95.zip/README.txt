OpenRGB headless build
----------------------
Source: https://github.com/hello-nexus/openrgb-headless
License: GPL-2.0-or-later (see LICENSE-OpenRGB.txt)
